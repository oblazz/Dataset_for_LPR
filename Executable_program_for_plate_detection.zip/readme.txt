PlateDetection Executable made by Seok Bong Yoo

1. Prerequisites for Deployment 

High-performence GPU, CUDA 9.1, and CUDNN 7.1.3 are required.

https://developer.nvidia.com/cuda-toolkit-archive 
https://developer.nvidia.com/rdp/cudnn-archive

2. Execution

- Decompress 3 egg files in model folder(model/).
- Locate model.weight file in model folder(model/).
- Locate test images in input folder(Caltech/images/).
- Write the position of each image in Caltech_images.txt.
- Run Test.cmd.
- Confirm many plate detection results by pressing any key in keyboard.


