# -*- coding: utf-8 -*-
"""
made by S. B. Yoo
@author: user
"""


import os
from os import listdir
from os.path import isfile, join
import cv2
import numpy as np

####################################################
in_folder='Input'  # jpg, txt 파일이 함께 있는 폴더 
out_folder='Augmented'  # 출력 폴더 (자동으로 생성)
rot = [5, -5, 10, -10, 15, -15]  # 회전 각도
####################################################

if not(os.path.isdir(out_folder)):
    os.mkdir(out_folder)

files = [f for f in listdir(in_folder) if isfile(join(in_folder, f))]

files_img = [x for x in files if x.find(".jpg") != -1] 
files_txt = [x for x in files if x.find(".txt") != -1] 

for i in range(0, len(files_img)-1):
    for j in range(0, len(rot)):
        fout_img = files_img[i]
        fout_img = out_folder+'/'+fout_img[:-4]+'_rot_'+str(rot[j])+fout_img[-4:]
        fout_txt =  files_txt[i]
        fout_txt = out_folder+'/'+fout_txt[:-4]+'_rot_'+str(rot[j])+fout_txt[-4:]
        img = cv2.imread(in_folder+'/'+files_img[i], cv2.IMREAD_COLOR)
        height, width, channels =  img.shape
        matrix = cv2.getRotationMatrix2D((width/2, height/2), rot[j], 1)
        img_rot = cv2.warpAffine(img, matrix, (width, height))
        cv2.imwrite(fout_img, img_rot) 
        f = open(in_folder+'/'+files_txt[i], 'r')
        fout = open(fout_txt, 'w')
        
        while True:
            line = f.readline()
            if not line: break
            line = line.split()
            
            c= int(line[0])
            xmin = (float(line[1])*width - float(line[2])/2.0)
            xmax = (xmin+float(line[3])*width)
            ymin = (float(line[2])*height - float(line[4])/2.0)
            ymax = (ymin+float(line[4])*height)
            
            p11=np.array([xmin, ymin, 1])
            p12=np.array([xmax, ymin, 1])
            p21=np.array([xmin, ymax, 1])
            p22=np.array([xmax, ymax, 1])
            center=np.array([float(line[1])*width, float(line[2])*height, 1])
            
            p11_rot=np.matmul(matrix,p11)
            p12_rot=np.matmul(matrix,p12)
            p21_rot=np.matmul(matrix,p21)
            p22_rot=np.matmul(matrix,p22)
            center_rot=np.matmul(matrix,center)
            
            xmin_rot= (min(p11_rot[0], p12_rot[0], p21_rot[0], p22_rot[0]))
            xmax_rot= (max(p11_rot[0], p12_rot[0], p21_rot[0], p22_rot[0]))
            ymin_rot= (min(p11_rot[1], p12_rot[1], p21_rot[1], p22_rot[1]))
            ymax_rot= (max(p11_rot[1], p12_rot[1], p21_rot[1], p22_rot[1]))
            
            w=((xmax_rot-xmin_rot)/width)
            h=((ymax_rot-ymin_rot)/height)
            x=center_rot[0]/width
            y=center_rot[1]/height
            
#            if x-w/2>=0 and x+w/2<1 and y-h/2>=0 and y+h/2<1:  #이미지 밖으로 벗어나는 박스 제외할 경우 주석 제거
            fout.write("%d %f %f %f %f\n" %(c, x, y, w, h))
    
    if i>0 and i%100==0:
        print(i,"장 처리완료/전체입력",len(files_img),"장")
    f.close()
    fout.close()
    
print("Data augmentation is completed\n")